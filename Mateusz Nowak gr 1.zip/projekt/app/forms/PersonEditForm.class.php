<?php

namespace app\forms;

class PersonEditForm {
	public $id;
	public $login;
	public $pass;
	public $email;
	public $nickname;
	public $country;
	public $firstname;
	public $lastname;
	public $rating;
	public $role;
}